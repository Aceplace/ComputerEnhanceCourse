from __future__ import annotations
import enum
import sys
from typing import Dict, Optional, Union
from io import StringIO
from bit_manipulation_helpers import get_bits_from_byte, BitIndexDirection, is_bit_set
from byte_reader import ByteReader


class RegisterType(enum.Enum):
    NONE = 0
    AL = enum.auto()
    AH = enum.auto()
    AX = enum.auto()
    BL = enum.auto()
    BH = enum.auto()
    BX = enum.auto()
    CL = enum.auto()
    CH = enum.auto()
    CX = enum.auto()
    DL = enum.auto()
    DH = enum.auto()
    DX = enum.auto()
    SP = enum.auto()
    BP = enum.auto()
    SI = enum.auto()
    DI = enum.auto()

    def __str__(self):
        return self.name.lower()


reg_to_register_type_w0_map: Dict[int, RegisterType] = {
    0b000: RegisterType.AL,
    0b001: RegisterType.CL,
    0b010: RegisterType.DL,
    0b011: RegisterType.BL,
    0b100: RegisterType.AH,
    0b101: RegisterType.CH,
    0b110: RegisterType.DH,
    0b111: RegisterType.BH,
}

reg_to_register_type_w1_map: Dict[int, RegisterType] = {
    0b000: RegisterType.AX,
    0b001: RegisterType.CX,
    0b010: RegisterType.DX,
    0b011: RegisterType.BX,
    0b100: RegisterType.SP,
    0b101: RegisterType.BP,
    0b110: RegisterType.SI,
    0b111: RegisterType.DI,
}


def get_register_from_reg(reg: int, word_bit_set: bool) -> RegisterType:
    if word_bit_set:
        return reg_to_register_type_w1_map[reg]
    else:
        return reg_to_register_type_w0_map[reg]


class DisplacementType(enum.Enum):
    NONE = 0
    EIGHT_BIT = enum.auto
    SIXTEEN_BIT = enum.auto


class EffectiveAddressCalculation:
    direct_address: EffectiveAddressCalculation = None

    def __init__(self, is_direct_address: bool, register_one: RegisterType, register_two: RegisterType, displacement_type: DisplacementType):
        self.is_direct_address = is_direct_address
        self.register_one = register_one
        self.register_two = register_two
        self.displacement_type = displacement_type

    def has_displacement(self):
        return self.displacement_type is not DisplacementType.NONE


EffectiveAddressCalculation.direct_address = EffectiveAddressCalculation(True, RegisterType.NONE, RegisterType.NONE, DisplacementType.NONE)

r_m_to_effective_address_calculation_mod_00: Dict[int, EffectiveAddressCalculation] = {
    0b000: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.SI, DisplacementType.NONE),
    0b001: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.DI, DisplacementType.NONE),
    0b010: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.SI, DisplacementType.NONE),
    0b011: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.DI, DisplacementType.NONE),
    0b100: EffectiveAddressCalculation(False, RegisterType.SI, RegisterType.NONE, DisplacementType.NONE),
    0b101: EffectiveAddressCalculation(False, RegisterType.DI, RegisterType.NONE, DisplacementType.NONE),
    0b110: EffectiveAddressCalculation.direct_address,
    0b111: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.NONE, DisplacementType.NONE),
}

r_m_to_effective_address_calculation_mod_01: Dict[int, EffectiveAddressCalculation] = {
    0b000: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.SI, DisplacementType.EIGHT_BIT),
    0b001: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.DI, DisplacementType.EIGHT_BIT),
    0b010: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.SI, DisplacementType.EIGHT_BIT),
    0b011: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.DI, DisplacementType.EIGHT_BIT),
    0b100: EffectiveAddressCalculation(False, RegisterType.SI, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b101: EffectiveAddressCalculation(False, RegisterType.DI, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b110: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b111: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.NONE, DisplacementType.EIGHT_BIT),
}

r_m_to_effective_address_calculation_mod_10: Dict[int, EffectiveAddressCalculation] = {
    0b000: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.SI, DisplacementType.SIXTEEN_BIT),
    0b001: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.DI, DisplacementType.SIXTEEN_BIT),
    0b010: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.SI, DisplacementType.SIXTEEN_BIT),
    0b011: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.DI, DisplacementType.SIXTEEN_BIT),
    0b100: EffectiveAddressCalculation(False, RegisterType.SI, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b101: EffectiveAddressCalculation(False, RegisterType.DI, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b110: EffectiveAddressCalculation(False, RegisterType.BP, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b111: EffectiveAddressCalculation(False, RegisterType.BX, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
}


class EffectiveAddress:
    def __init__(self, effective_address_calculation: EffectiveAddressCalculation, displacement: Optional[int]):
        self.effective_address_calculation = effective_address_calculation
        self.displacement = displacement

    def __str__(self) -> str:
        return self._get_decode_str_with_displacement()

    def _get_decode_str_with_displacement(self):
        if self.effective_address_calculation.is_direct_address:
            assert self.displacement is not None, 'Need a displacement for direct address'
            return f'[{self.displacement}]'

        if self.displacement is not None:
            displacement_str_part: str = f'+ {self.displacement}' if self.displacement >= 0 else f'- {abs(self.displacement)}'
            if self.effective_address_calculation.register_two is not RegisterType.NONE:
                return f'[{self.effective_address_calculation.register_one} + {self.effective_address_calculation.register_two} {displacement_str_part}]'
            else:
                return f'[{self.effective_address_calculation.register_one} {displacement_str_part}]'

        if self.effective_address_calculation.register_two is not RegisterType.NONE:
            return f'[{self.effective_address_calculation.register_one} + {self.effective_address_calculation.register_two}]'
        else:
            return f'[{self.effective_address_calculation.register_one}]'


def get_effective_address_calculation_from_r_m_mod(r_m: int, mod: int) -> EffectiveAddressCalculation:
    assert mod != 0b11, 'Register to Register mode does not use effective address'
    if mod == 0b00:  # no displacement
        return r_m_to_effective_address_calculation_mod_00[r_m]
    elif mod == 0b01:  # 8 bit offset
        return r_m_to_effective_address_calculation_mod_01[r_m]
    return r_m_to_effective_address_calculation_mod_10[r_m]  # 16 bit offset


def explicit_applied_immediate_value_str(value: int, is_word: bool) -> str:
    return f'word  {value}' if is_word else f'byte  {value}'


class InstructionType(enum.Enum):
    NONE = 0
    MOV = enum.auto

    def __str__(self):
        return self.name.lower()


class OperandType(enum.Enum):
    NONE = 0
    REGISTER = enum.auto()
    EFFECTIVE_ADDRESS = enum.auto()
    IMMEDIATE_VALUE_BYTE = enum.auto()
    IMMEDIATE_VALUE_WORD = enum.auto()

    def is_immediate_value(self):
        return self in [OperandType.IMMEDIATE_VALUE_BYTE, OperandType.IMMEDIATE_VALUE_WORD]


class Operand:
    def __init__(self, operand_type: OperandType = OperandType.NONE, value: Union[RegisterType, EffectiveAddress, int, None] = None):
        self.operand_type: OperandType = operand_type
        self.value: Union[RegisterType, EffectiveAddressCalculation, int, None] = value


class Operation:
    def __init__(self):
        self.instruction_type: InstructionType = InstructionType.NONE
        self.operand_one: Operand = Operand()
        self.operand_two: Operand = Operand()

    def __str__(self):
        return self.get_decode_str()

    def __repr__(self):
        return f'op({self.get_decode_str()})'

    def get_decode_str(self):
        if self.operand_two.operand_type.is_immediate_value():
            immediate_value: int = self.operand_two.value
            #  check for whether an explicit immediate value is required
            if self.operand_one.operand_type == OperandType.EFFECTIVE_ADDRESS:
                is_word: bool = self.operand_two.operand_type == OperandType.IMMEDIATE_VALUE_WORD
                operand_two_str: str = f'word  {immediate_value}' if is_word else f'byte  {immediate_value}'
            else:
                operand_two_str: str = f'{immediate_value}'
        else:  # register or effective address
            operand_two_str: str = str(self.operand_two.value)

        return f'{self.instruction_type} {self.operand_one.value}, {operand_two_str}'


def create_immediate_value_operand(value: int, is_word: bool):
    result: Operand = Operand()
    result.operand_type = OperandType.IMMEDIATE_VALUE_WORD if is_word else OperandType.IMMEDIATE_VALUE_BYTE
    result.value = value
    return result


def create_register_operand(register_type: RegisterType):
    result: Operand = Operand()
    result.operand_type = OperandType.REGISTER
    result.value = register_type
    return result


def create_effective_address_operand(effective_address_calculation: EffectiveAddressCalculation, displacement: Optional[int]):
    result: Operand = Operand()
    result.operand_type = OperandType.EFFECTIVE_ADDRESS
    result.value = EffectiveAddress(effective_address_calculation, displacement)
    return result


def contains_mov_opcode(opcode: int) -> bool:
    opcode_four: int = get_bits_from_byte(opcode, 0, 4, BitIndexDirection.FROM_LEFT)
    opcode_six: int = get_bits_from_byte(opcode, 0, 6, BitIndexDirection.FROM_LEFT)
    opcode_seven: int = get_bits_from_byte(opcode, 0, 7, BitIndexDirection.FROM_LEFT)

    return opcode_four == 0b1011 or opcode_seven == 0b1010000 or opcode_seven == 0b1010001 or opcode_seven == 0b1100011 or opcode_six == 0b100010


def handle_mov_sub_cmp_instruction(current_byte: int, byte_reader: ByteReader) -> Operation:
    opcode_four: int = get_bits_from_byte(current_byte, 0, 4, BitIndexDirection.FROM_LEFT)
    opcode_seven: int = get_bits_from_byte(current_byte, 0, 7, BitIndexDirection.FROM_LEFT)

    operation: Operation = Operation()
    operation.instruction_type = InstructionType.MOV

    next_line: str
    if opcode_four == 0b1011:
        word_bit_set: bool = is_bit_set(current_byte, 3, BitIndexDirection.FROM_RIGHT)
        reg: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_RIGHT)

        immediate_value: int = byte_reader.read_one_or_two_bytes_as_u8_or_u16(word_bit_set)
        dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
        operation.operand_one = create_register_operand(dst_register)
        operation.operand_two = create_immediate_value_operand(immediate_value, word_bit_set)
        # next_line = f'mov {dst_register}, {immediate_value}\n'
    elif opcode_seven == 0b1010000:  # mov memory to accumulator
        word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)

        memory_address: int = byte_reader.read_one_or_two_bytes_as_u8_or_u16(word_bit_set)

        # dst_register: RegisterType = RegisterType.AX
        effective_address_calculation: EffectiveAddressCalculation = EffectiveAddressCalculation.direct_address

        operation.operand_one = create_register_operand(RegisterType.AX)
        operation.operand_two = create_effective_address_operand(effective_address_calculation, memory_address)
        # effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(memory_address)
        # next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
    elif opcode_seven == 0b1010001:  # mov accumulator to memory
        word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)

        memory_address: int = byte_reader.read_one_or_two_bytes_as_u8_or_u16(word_bit_set)
        src_register: RegisterType = RegisterType.AX
        effective_address_calculation: EffectiveAddressCalculation = EffectiveAddressCalculation.direct_address

        operation.operand_one = create_effective_address_operand(effective_address_calculation, memory_address)
        operation.operand_two = create_register_operand(RegisterType.AX)
        # effective_address_decode_str: str = effective_address_calculation.get_decode_str_with_displacement(memory_address)
        # next_line = f'mov {effective_address_decode_str}, {src_register}\n'
    elif opcode_seven == 0b1100011:  # mov immediate to register/memory
        word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)
        current_byte: int = byte_reader.read_next_byte_as_u8()
        mod: int = get_bits_from_byte(current_byte, 0, 2, BitIndexDirection.FROM_LEFT)
        reg: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_LEFT)
        r_m: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_RIGHT)
        assert reg == 0, 'Reg bits should be zero'

        if mod == 0b11:  # immediate to register
            dst_register: RegisterType = get_register_from_reg(r_m, word_bit_set)

            immediate_value: int = byte_reader.read_one_or_two_bytes_as_u8_or_u16(word_bit_set)

            operation.operand_one = create_register_operand(dst_register)
            operation.operand_two = create_immediate_value_operand(immediate_value, word_bit_set)
            # next_line = f'mov {dst_register}, {immediate_value}\n'
        elif mod == 0b00 and r_m == 0b110:
            assert False, f'Direct Address not supported for mov immediate to register/memory'
        else:  # immediate to memory
            has_displacement: bool = mod > 0

            displacement: Optional[int]
            if has_displacement:
                if mod == 0b10:  # 16 bit displacement
                    displacement: int = byte_reader.read_next_two_byte_as_s16()
                else:  # 8 bit displacement
                    displacement = byte_reader.read_next_byte_as_s8()
            else:
                displacement = None

            effective_address_calculation: EffectiveAddressCalculation = get_effective_address_calculation_from_r_m_mod(r_m, mod)
            # effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(displacement)

            immediate_value: int = byte_reader.read_one_or_two_bytes_as_u8_or_u16(word_bit_set)

            operation.operand_one = create_effective_address_operand(effective_address_calculation, displacement)
            operation.operand_two = create_immediate_value_operand(immediate_value, word_bit_set)
            # immediate_value_str = explicit_applied_immediate_value_str(immediate_value, word_bit_set)
            # next_line = f'mov {effective_address_decode_str}, {immediate_value_str}\n'
    else:  # opcode_six == 0b100010:  # mov register/memory to/from register
        dst_bit_set: bool = is_bit_set(current_byte, 1, BitIndexDirection.FROM_RIGHT)
        word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)
        current_byte: int = byte_reader.read_next_byte_as_u8()
        mod: int = get_bits_from_byte(current_byte, 0, 2, BitIndexDirection.FROM_LEFT)
        reg: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_LEFT)
        r_m: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_RIGHT)

        if mod == 0b11:  # register to register
            if not dst_bit_set:
                src_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                dst_register: RegisterType = get_register_from_reg(r_m, word_bit_set)
            else:
                src_register: RegisterType = get_register_from_reg(r_m, word_bit_set)
                dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)

            operation.operand_one = create_register_operand(dst_register)
            operation.operand_two = create_register_operand(src_register)
            # next_line = f'mov {dst_register}, {src_register}\n'
        elif mod == 0b00 and r_m == 0b110:  # direct address mode
            effective_address_calculation: EffectiveAddressCalculation = get_effective_address_calculation_from_r_m_mod(r_m, mod)
            dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
            memory_address: int = byte_reader.read_next_two_byte_as_u16()
            # effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(memory_address)

            operation.operand_one = create_register_operand(dst_register)
            operation.operand_two = create_effective_address_operand(effective_address_calculation, memory_address)
            # next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
        else:  # memory mode
            has_displacement: bool = mod > 0

            displacement: Optional[int]
            if has_displacement:
                if mod == 0b10:  # 16 bit displacement
                    displacement: int = byte_reader.read_next_two_byte_as_s16()
                else:  # 8 bit displacement
                    displacement = byte_reader.read_next_byte_as_s8()
            else:
                displacement = None

            effective_address_calculation: EffectiveAddressCalculation = get_effective_address_calculation_from_r_m_mod(r_m, mod)
            # effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(displacement)
            if dst_bit_set:
                dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                operation.operand_one = create_register_operand(dst_register)
                operation.operand_two = create_effective_address_operand(effective_address_calculation, displacement)
                # next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
            else:
                src_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                operation.operand_one = create_effective_address_operand(effective_address_calculation, displacement)
                operation.operand_two = create_register_operand(src_register)
                # next_line = f'mov {effective_address_decode_str}, {src_register}\n'
    return operation


def decode(byte_reader: ByteReader) -> str:
    output: StringIO = StringIO()
    output.write('bits 16\n')

    operations: list[Operation] = []
    while not byte_reader.is_at_end():
        current_byte: int = byte_reader.read_next_byte_as_u8()

        if contains_mov_opcode(current_byte):
            operations.append(handle_mov_sub_cmp_instruction(current_byte, byte_reader))
        else:
            assert False, f'Unknown opcode {current_byte}'

    output.write('\n'.join([str(operation) for operation in operations]))
    output.write('\n')
    output.seek(0)
    return output.getvalue()


def main():
    file_name: str = sys.argv[1]
    output_file_name: str = f'{file_name}_my_decoder.asm'

    with open(file_name, 'rb') as file:
        file_bytes = file.read()
        byte_reader: ByteReader = ByteReader(file_bytes)
        decoded_file = decode(byte_reader)

    with open(output_file_name, 'w') as file:
        file.write(decoded_file)


if __name__ == "__main__":
    main()
