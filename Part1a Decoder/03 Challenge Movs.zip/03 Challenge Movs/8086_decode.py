from __future__ import annotations
import enum
import sys
from typing import Dict, Optional
from io import StringIO
from bit_manipulation_helpers import get_bits_from_byte, BitIndexDirection, is_bit_set
from byte_reader import ByteReader


class RegisterType(enum.Enum):
    NONE = 0
    AL = enum.auto()
    AH = enum.auto()
    AX = enum.auto()
    BL = enum.auto()
    BH = enum.auto()
    BX = enum.auto()
    CL = enum.auto()
    CH = enum.auto()
    CX = enum.auto()
    DL = enum.auto()
    DH = enum.auto()
    DX = enum.auto()
    SP = enum.auto()
    BP = enum.auto()
    SI = enum.auto()
    DI = enum.auto()

    def __str__(self):
        return self.name.lower()

    def needs_explicit_immediate_value(self) -> bool:
        return self in [RegisterType.SP, RegisterType.BP, RegisterType.SI, RegisterType.DI]

    def explicit_applied_immediate_value_str(self, value: int, is_word: bool) -> str:
        if self.needs_explicit_immediate_value():
            return f'word  {value}' if is_word else f'byte  {value}'
        return f'{value}'


reg_to_register_type_w0_map: Dict[int, RegisterType] = {
    0b000: RegisterType.AL,
    0b001: RegisterType.CL,
    0b010: RegisterType.DL,
    0b011: RegisterType.BL,
    0b100: RegisterType.AH,
    0b101: RegisterType.CH,
    0b110: RegisterType.DH,
    0b111: RegisterType.BH,
}

reg_to_register_type_w1_map: Dict[int, RegisterType] = {
    0b000: RegisterType.AX,
    0b001: RegisterType.CX,
    0b010: RegisterType.DX,
    0b011: RegisterType.BX,
    0b100: RegisterType.SP,
    0b101: RegisterType.BP,
    0b110: RegisterType.SI,
    0b111: RegisterType.DI,
}


def get_register_from_reg(reg: int, word_bit_set: bool) -> RegisterType:
    if word_bit_set:
        return reg_to_register_type_w1_map[reg]
    else:
        return reg_to_register_type_w0_map[reg]


class DisplacementType(enum.Enum):
    NONE = 0
    EIGHT_BIT = enum.auto
    SIXTEEN_BIT = enum.auto


class EffectiveAddress:
    direct_address: EffectiveAddress = None

    def __init__(self, is_direct_address: bool, register_one: RegisterType, register_two: RegisterType, displacement_type: DisplacementType):
        self.is_direct_address = is_direct_address
        self.register_one = register_one
        self.register_two = register_two
        self.displacement_type = displacement_type

    def get_decode_str_with_displacement(self, displacement: Optional[int]):
        if self.is_direct_address:
            assert displacement is not None, 'Need a displacement for direct address'
            return f'[{displacement}]'

        if displacement is not None:
            displacement_str_part: str = f'+ {displacement}' if displacement >= 0 else f'- {abs(displacement)}'
            if self.register_two is not RegisterType.NONE:
                return f'[{self.register_one} + {self.register_two} {displacement_str_part}]'
            else:
                return f'[{self.register_one} {displacement_str_part}]'

        if self.register_two is not RegisterType.NONE:
            return f'[{self.register_one} + {self.register_two}]'
        else:
            return f'[{self.register_one}]'


EffectiveAddress.direct_address = EffectiveAddress(True, RegisterType.NONE, RegisterType.NONE, DisplacementType.NONE)

r_m_to_effective_address_mod_00: Dict[int, EffectiveAddress] = {
    0b000: EffectiveAddress(False, RegisterType.BX, RegisterType.SI, DisplacementType.NONE),
    0b001: EffectiveAddress(False, RegisterType.BX, RegisterType.DI, DisplacementType.NONE),
    0b010: EffectiveAddress(False, RegisterType.BP, RegisterType.SI, DisplacementType.NONE),
    0b011: EffectiveAddress(False, RegisterType.BP, RegisterType.DI, DisplacementType.NONE),
    0b100: EffectiveAddress(False, RegisterType.SI, RegisterType.NONE, DisplacementType.NONE),
    0b101: EffectiveAddress(False, RegisterType.DI, RegisterType.NONE, DisplacementType.NONE),
    0b110: EffectiveAddress.direct_address,
    0b111: EffectiveAddress(False, RegisterType.BX, RegisterType.NONE, DisplacementType.NONE),
}

r_m_to_effective_address_mod_01: Dict[int, EffectiveAddress] = {
    0b000: EffectiveAddress(False, RegisterType.BX, RegisterType.SI, DisplacementType.EIGHT_BIT),
    0b001: EffectiveAddress(False, RegisterType.BX, RegisterType.DI, DisplacementType.EIGHT_BIT),
    0b010: EffectiveAddress(False, RegisterType.BP, RegisterType.SI, DisplacementType.EIGHT_BIT),
    0b011: EffectiveAddress(False, RegisterType.BP, RegisterType.DI, DisplacementType.EIGHT_BIT),
    0b100: EffectiveAddress(False, RegisterType.SI, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b101: EffectiveAddress(False, RegisterType.DI, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b110: EffectiveAddress(False, RegisterType.BP, RegisterType.NONE, DisplacementType.EIGHT_BIT),
    0b111: EffectiveAddress(False, RegisterType.BX, RegisterType.NONE, DisplacementType.EIGHT_BIT),
}

r_m_to_effective_address_mod_10: Dict[int, EffectiveAddress] = {
    0b000: EffectiveAddress(False, RegisterType.BX, RegisterType.SI, DisplacementType.SIXTEEN_BIT),
    0b001: EffectiveAddress(False, RegisterType.BX, RegisterType.DI, DisplacementType.SIXTEEN_BIT),
    0b010: EffectiveAddress(False, RegisterType.BP, RegisterType.SI, DisplacementType.SIXTEEN_BIT),
    0b011: EffectiveAddress(False, RegisterType.BP, RegisterType.DI, DisplacementType.SIXTEEN_BIT),
    0b100: EffectiveAddress(False, RegisterType.SI, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b101: EffectiveAddress(False, RegisterType.DI, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b110: EffectiveAddress(False, RegisterType.BP, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
    0b111: EffectiveAddress(False, RegisterType.BX, RegisterType.NONE, DisplacementType.SIXTEEN_BIT),
}


def get_effective_address(r_m: int, mod: int) -> EffectiveAddress:
    assert mod != 0b11, 'Register to Register mode does not use effective address'
    if mod == 0b00:  # no displacement
        return r_m_to_effective_address_mod_00[r_m]
    elif mod == 0b01:  # 8 bit offset
        return r_m_to_effective_address_mod_01[r_m]
    return r_m_to_effective_address_mod_10[r_m]  # 16 bit offset


def explicit_applied_immediate_value_str(value: int, is_word: bool) -> str:
    return f'word  {value}' if is_word else f'byte  {value}'


def decode(byte_reader: ByteReader) -> str:
    output: StringIO = StringIO('bit 16\n')
    while not byte_reader.is_at_end():
        current_byte: int = byte_reader.read_next_byte_as_u8()

        opcode_four: int = get_bits_from_byte(current_byte, 0, 4, BitIndexDirection.FROM_LEFT)
        opcode_six: int = get_bits_from_byte(current_byte, 0, 6, BitIndexDirection.FROM_LEFT)
        opcode_seven: int = get_bits_from_byte(current_byte, 0, 7, BitIndexDirection.FROM_LEFT)

        next_line: str
        if opcode_four == 0b1011:
            word_bit_set: bool = is_bit_set(current_byte, 3, BitIndexDirection.FROM_RIGHT)
            reg: int = get_bits_from_byte(current_byte, 3, 4, BitIndexDirection.FROM_RIGHT)

            if word_bit_set:  # 2 bytes
                immediate_value: int = byte_reader.read_next_two_byte_as_u16()
            else:  # 1 byte
                immediate_value: int = byte_reader.read_next_byte_as_u8()

            dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
            immediate_value_str = dst_register.explicit_applied_immediate_value_str(immediate_value, word_bit_set)
            next_line = f'mov {dst_register}, {immediate_value_str}\n'
        elif opcode_seven == 0b1010000:  # mov memory to accumulator
            word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)

            if word_bit_set:  # 2 bytes
                memory_address: int = byte_reader.read_next_two_byte_as_u16()
            else:  # 1 byte
                memory_address: int = byte_reader.read_next_byte_as_u8()

            dst_register: RegisterType = RegisterType.AX
            effective_address: EffectiveAddress = EffectiveAddress.direct_address

            effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(memory_address)
            next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
        elif opcode_seven == 0b1010001:  # mov accumulator to memory
            word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)

            if word_bit_set:  # 2 bytes
                memory_address: int = byte_reader.read_next_two_byte_as_u16()
            else:  # 1 byte
                memory_address: int = byte_reader.read_next_byte_as_u8()

            src_register: RegisterType = RegisterType.AX
            effective_address: EffectiveAddress = EffectiveAddress.direct_address

            effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(memory_address)
            next_line = f'mov {effective_address_decode_str}, {src_register}\n'
        elif opcode_seven == 0b1100011:  # mov immediate to register/memory
            word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)
            current_byte: int = byte_reader.read_next_byte_as_u8()
            mod: int = get_bits_from_byte(current_byte, 0, 2, BitIndexDirection.FROM_LEFT)
            reg: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_LEFT)
            r_m: int = get_bits_from_byte(current_byte, 0, 3, BitIndexDirection.FROM_RIGHT)
            assert reg == 0, 'Reg bits should be zero'

            if mod == 0b11:  # immediate to register
                dst_register: RegisterType = get_register_from_reg(r_m, word_bit_set)

                if word_bit_set:  # 2 bytes
                    immediate_value: int = byte_reader.read_next_two_byte_as_u16()
                else:  # 1 byte
                    immediate_value: int = byte_reader.read_next_byte_as_u8()

                immediate_value_str = dst_register.explicit_applied_immediate_value_str(immediate_value, word_bit_set)
                next_line = f'mov {dst_register}, {immediate_value_str}\n'
            elif mod == 0b00 and r_m == 0b110:
                assert False, f'Direct Address not supported for mov immediate to register/memory'
            else:  # immediate to memory
                has_displacement: bool = mod > 0

                displacement: Optional[int]
                if has_displacement:
                    if mod == 0b10:  # 16 bit displacement
                        displacement: int = byte_reader.read_next_two_byte_as_s16()
                    else:  # 8 bit displacement
                        displacement = byte_reader.read_next_byte_as_s8()
                else:
                    displacement = None

                effective_address: EffectiveAddress = get_effective_address(r_m, mod)
                effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(displacement)

                if word_bit_set:  # 2 bytes
                    immediate_value: int = byte_reader.read_next_two_byte_as_u16()
                else:  # 1 byte
                    immediate_value: int = byte_reader.read_next_byte_as_u8()

                immediate_value_str = explicit_applied_immediate_value_str(immediate_value, word_bit_set)
                next_line = f'mov {effective_address_decode_str}, {immediate_value_str}\n'
        elif opcode_six == 0b100010:  # mov register/memory to/from register
            dst_bit_set: bool = is_bit_set(current_byte, 1, BitIndexDirection.FROM_RIGHT)
            word_bit_set: bool = is_bit_set(current_byte, 0, BitIndexDirection.FROM_RIGHT)
            current_byte: int = byte_reader.read_next_byte_as_u8()
            mod: int = get_bits_from_byte(current_byte, 0, 2, BitIndexDirection.FROM_LEFT)
            reg: int = get_bits_from_byte(current_byte, 2, 3, BitIndexDirection.FROM_LEFT)
            r_m: int = get_bits_from_byte(current_byte, 0, 3, BitIndexDirection.FROM_RIGHT)

            if mod == 0b11:  # register to register
                if not dst_bit_set:
                    src_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                    dst_register: RegisterType = get_register_from_reg(r_m, word_bit_set)
                else:
                    src_register: RegisterType = get_register_from_reg(r_m, word_bit_set)
                    dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)

                next_line = f'mov {dst_register}, {src_register}\n'
            elif mod == 0b00 and r_m == 0b110:  # direct address mode
                effective_address: EffectiveAddress = get_effective_address(r_m, mod)
                dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                memory_address: int = byte_reader.read_next_two_byte_as_u16()
                effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(memory_address)
                next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
            else:  # memory mode
                has_displacement: bool = mod > 0

                displacement: Optional[int]
                if has_displacement:
                    if mod == 0b10:  # 16 bit displacement
                        displacement: int = byte_reader.read_next_two_byte_as_s16()
                    else:  # 8 bit displacement
                        displacement = byte_reader.read_next_byte_as_s8()
                else:
                    displacement = None

                effective_address: EffectiveAddress = get_effective_address(r_m, mod)
                effective_address_decode_str: str = effective_address.get_decode_str_with_displacement(displacement)
                if dst_bit_set:
                    dst_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                    next_line = f'mov {dst_register}, {effective_address_decode_str}\n'
                else:
                    src_register: RegisterType = get_register_from_reg(reg, word_bit_set)
                    next_line = f'mov {effective_address_decode_str}, {src_register}\n'
        else:
            assert False, f'Unknown opcode {opcode_six}'
        output.write(next_line)

    output.seek(0)
    return output.getvalue()


def main():
    file_name: str = sys.argv[1]
    output_file_name: str = f'{file_name}_my_decoder.asm'

    with open(file_name, 'rb') as file:
        file_bytes = file.read()
        byte_reader: ByteReader = ByteReader(file_bytes)
        decoded_file = decode(byte_reader)

    with open(output_file_name, 'w') as file:
        file.write(decoded_file)


if __name__ == "__main__":
    main()
